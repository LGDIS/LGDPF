# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Localpersonfinder::Application.config.secret_token = '4c9c4b5842ea5830298eba294fda9d5ef659075abf64daca2f455ec585f31ba2c398e19b6891c7459b2ce37619f012a94b6df61cb45c60d497403b2310b76370'
