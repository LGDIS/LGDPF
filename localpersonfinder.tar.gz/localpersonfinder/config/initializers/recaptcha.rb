Recaptcha.configure do |config|
  config.public_key  = '6LeZxtoSAAAAAKTiXT5Nk1YjGrNIPkRyI7hhJpk-'
  config.private_key = '6LeZxtoSAAAAAGxjcukZp_UxE3VtyGinq4D_xFhn'
  config.proxy = 'inet-gw.adniss.jp:80'
end