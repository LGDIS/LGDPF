// Selected people in duplicate handling mode.
var checked_ids = {};

// Initialize JavaScript state based on hidden fields.
function init_dup_state() {
    var dup_mode_enabled = $('#dup_state').val() == 'true';
    set_dup_mode(dup_mode_enabled, true);
}

// Switched duplicate handling UI on or off.
function set_dup_mode(enable, init) {
    $('#dup_on_link').css("display", enable ? 'none' : '');
    $('#dup_off_link').css("display", enable ? '' : 'none');
    $('#dup_form').css("display", enable ? '' : 'none');
    $('#dup_state').attr("cheched", enable);

    var elems = document.getElementsByTagName('input');
    for (var i = 0; i < elems.length; ++i) {
        var elem = elems[i];
        if (elem.type.toLowerCase() == 'checkbox' && elem.name == 'dup') {
            elem.style.display = enable ? 'block' : 'none';
            if (init) {
                check_dup(elem);
            } else {
                elem.checked = false;
            }
        }
    }
    if (!init) {
        checked_ids = {};
        $('#dup_count').innerHTML = '0';
        $('#dup_go').disabled = true;
    }
    return false;
}

// Handles checking / unchecking a person for duplicate handling.
function check_dup(elem) {
    if (elem.checked) {
        checked_ids[elem.value] = true;
    } else {
        delete checked_ids[elem.value];
    }
    var count = 0;
    for (prop in checked_ids) {
        ++count;
    }
    $('#dup_count').text(count);
    $('#dup_go').attr("disabled", (count < 2 || count > 3));
}

// Before submit, collect IDs for duplicate marking.
function mark_dup() {
    var ind = 0;
    for (prop in checked_ids) {
        $('#id' + (++ind)).value = prop;
        if (ind == 3) {
            break;
        }
    }
}

// Dynamic behavior for the image URL / upload entry fields.
// If for_note is true, target fields in the Note entry form; otherwise target
// fields in the Person entry form.
function update_image_input(for_note) {
    var id_prefix = for_note ? '#note_' : '#person_';
    var upload = $(id_prefix + 'photo_input_upload').attr("checked");
    if (upload) {
        $(id_prefix + 'photo_url').removeAttr("disabled").focus();
        $(id_prefix + 'remote_photo_url_url').attr("disabled", true);
    }
    else {
        $(id_prefix + 'photo_url').attr("disabled", true);
        $(id_prefix + 'remote_photo_url_url').removeAttr("disabled").focus()
    }
}

// Dynamic behavior for the Person entry form.
function update_clone() {
    var display_original = $('#clone_clone_input_no').attr("checked") ? 'inline' : 'none';
    var display_clone = $('#clone_clone_input_yes').attr("checked") ? 'inline' : 'none';
    var display_source = $('#clone_clone_input_yes').attr("checked") ? '' : 'none';

    $('#author_name_original').css("display", display_original);
    $('#author_phone_original').css("display", display_original);
    $('#author_email_original').css("display", display_original);
    $('#author_name_clone').css("display", display_clone);
    $('#author_phone_clone').css("display", display_clone);
    $('#author_email_clone').css("display", display_clone);
    $('#source_url_row').css("display", display_source);
    $('#source_date_row').css("display", display_source);
    $('#source_name_row').css("display", display_source);
}

$(document).ready(function(){
    if ($("#note_author_made_contact_true").attr('checked')){
        update_contact();
    }
  });

// Dynamic behavior for the Note entry form.
function update_contact() {
    var display_contact = $('#note_author_made_contact_true').attr('checked') ? '' : 'none';
    if($('#note_author_made_contact_true').attr('checked')){
        $('#note_author_made_contact_true').attr('checked','checked');
        $('#note_author_made_contact_false').removeAttr('checked');
    }
    else{
        $('#note_author_made_contact_true').removeAttr('checked');
        $('#note_author_made_contact_false').attr('checked','checked');
    }
    $('#contact_row').css("display", display_contact);
}

// メモの表示切り替え
function set_display(id_or_elem, hide) {
    var hide_text = hide ? 'none' : '';
    if (typeof(id_or_elem) == 'string') {
        document.getElementById(id_or_elem).style.display = hide_text;
    } else {
        id_or_elem.style.display = hide_text;
    }
}

function hide_unhide_note_contents(note_contents_id) {
    var note = document.getElementById(note_contents_id + '-contents');
    var hidden = note.style.display == 'none';
    set_display(note, !hidden);
    set_display(note_contents_id + '-reveal-note', hidden);
    set_display(note_contents_id + '-hide-note', !hidden);
    set_display(note_contents_id + '-mark-not-spam', !hidden);
}

//------------------------------------------------------------------------------
//                             GoogleMaps用
//------------------------------------------------------------------------------



// The default viewport of the map.
var DEFAULT_MAP_CENTER = new google.maps.LatLng(38.4342786010442,141.30284786224365);
var DEFAULT_MAP_ZOOM = 6;

// key: map_id, value: LatLng
var latlng_by_map_id = {};
// key: map_id, value: address string
var address_by_map_id = {};
// key: map_id, value: boolean
var map_initialized = {};

function parseLatLng(latlng_str) {
    var latlng_split = latlng_str.split(',');
    if (latlng_split.length == 2) {
        var lat = parseFloat(latlng_split[0])
        var lng = parseFloat(latlng_split[1])
        if (!isNaN(lat) && !isNaN(lng)) {
            return new google.maps.LatLng(lat, lng);
        }
    }
}

function printLatLng(latlng) {
    return latlng.lat() + ',' + latlng.lng();
}

// Tries to parse "location_str" as a latlng or geocodes it as an address.
function parseLatLngOrGeocode(location_str, onLatLngAvailable) {
    var latlng = parseLatLng(location_str);
    if (latlng) {
        onLatLngAvailable(latlng);
    } else {
        // If location_str is not a lat/lng pair, try geocoding it as an address.
        var geocoder = new google.maps.Geocoder();
        geocoder.geocode({
            address: location_str
        }, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK && results[0]) {
                onLatLngAvailable(results[0].geometry.location);
            }
        });
    }
}

function parseLatLngOrGeocodeAndStore(location_str, map_id) {
    // On success, store the latlng and make the show link visible.
    function onLatLngAvailable(latlng) {
        latlng_by_map_id[map_id] = latlng;
        document.getElementById(map_id + '_show_link').style.display = '';
    }
    parseLatLngOrGeocode(location_str, onLatLngAvailable);
}

// Initializes a map at the canvas whose id is "map_id" and drops a marker at
// the map's center.  "center" and "zoom" may be undefined, in which case the
// default values are used.
function initMap(map_id, center, zoom) {
    var map_canvas = document.getElementById(map_id);
    if (!map_canvas) return;

    var map = new google.maps.Map(map_canvas, {
        center: center || DEFAULT_MAP_CENTER,
        zoom: zoom || DEFAULT_MAP_ZOOM,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    });
    var marker = new google.maps.Marker({
        map: map,
        position: center || DEFAULT_MAP_CENTER
    });

    return {
        map: map,
        marker: marker
    };
}

// Initializes a map and a marker, using the lat/lng stored in latlng_by_map_id
// as the center.
function initMarkeredMap(map_id) {
    var latlng = latlng_by_map_id[map_id];
    if (latlng) {
        initMap(map_id, latlng);
    }
}

// Initializes a map with the default viewport and listens to click events.
// When the map is clicked, drop a marker at the clicked location, and updates
// the location text field with the lat/lng of the location. It also queries
// the geocoder to reverse geocode the lat/lng, and if successful, updates the
// text field with the reverse-geocoded address.
function initClickableMap(map_id) {
    var markered_map = initMap(map_id);
    var location_field = document.getElementById(map_id + '_location_field');
    if (!markered_map || !location_field) return;

    markered_map.map.setOptions({
        draggableCursor: 'pointer'
    });
    markered_map.marker.setVisible(false);

    var onLocationFieldChanged = function() {
        parseLatLngOrGeocode(location_field.value, function(latlng) {
            markered_map.map.panTo(latlng);
            markered_map.marker.setPosition(latlng);
            markered_map.marker.setVisible(true);
        });
    };
    // Updates the marker position according to the location field value.
    location_field.onchange = onLocationFieldChanged;
    if (location_field.value) {
        onLocationFieldChanged();
    }

    // Updates the location field value according to the marker position.
    var geocoder = new google.maps.Geocoder();
    google.maps.event.addListener(markered_map.map, "click", function(event) {
        var latlng = event.latLng;
        latlng_by_map_id[map_id] = latlng;

        // Show the marker at the clicked location and updates the text field.
        markered_map.marker.setPosition(latlng);
        markered_map.marker.setVisible(true);
        location_field.value = printLatLng(latlng);

        // Try reverse geocoding the lat/lng location to an address.
        geocoder.geocode({
            location: latlng
        }, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK && results[0]) {
                location_field.value = address_by_map_id[map_id] =
                results[0].formatted_address;
            }
        });
    });
}

// Toggles the visibility of an element specified by the id and returns the
// visibility of the element after the toggle.
function toggle(id) {
    var element = document.getElementById(id);
    var to_be_visible = element.style.display == 'none';
    element.style.display = to_be_visible ? '' : 'none';
    return to_be_visible;
}

// Toggles the value of location field between lat/long and address string.
function toggleLatLngAndAddress(map_id) {
    var location_field = document.getElementById(map_id + '_location_field');
    if (!location_field) return;
    if (toggle('switch_to_latlng_link')) {
        var address = address_by_map_id[map_id];
        if (address) {
            location_field.value = address;
        }
    }
    if (toggle('switch_to_address_link')) {
        var latlng = latlng_by_map_id[map_id];
        if (latlng) {
            location_field.value = printLatLng(latlng);
        }
    }
}

// Toggles the visibility of the map and the show/hide link.
function toggleMap(map_id) {
    toggle(map_id);
    toggle(map_id + '_show_link');
    toggle(map_id + '_hide_link');
}

function toggleMarkeredMap(map_id) {
    toggleMap(map_id);
    if (!map_initialized[map_id]) {
        initMarkeredMap(map_id);
        map_initialized[map_id] = true;
    }
}

function toggleClickableMap(map_id) {
    toggleMap(map_id);
    if (!map_initialized[map_id]) {
        initClickableMap(map_id);
        map_initialized[map_id] = true;
    }
}

