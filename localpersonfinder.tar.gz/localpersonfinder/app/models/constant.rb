# -*- coding:utf-8 -*-
class Constant < ActiveRecord::Base
  attr_accessible :kind1, :kind2, :kind3, :text, :value, :_order
end